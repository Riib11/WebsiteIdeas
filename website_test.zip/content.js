var content = {
    "index/": {
        "forum": "https://people.reed.edu/~blancheh/forum/redirect.html",
        "projects/": {
            "MusicGenerator": "http://people.reed.edu/~blancheh/webaudiotest.html",
        },
        "math/": {
            "ExplodingCat": "http://people.reed.edu/~blancheh/explodingcat.html"
        },
        "writing/": {
            "Writings": "http://riibfeed.blogspot.com/",
            "OldWritings": "https://sites.google.com/site/riibfeed/",
            "Poetry": "https://henryspoetry.tumblr.com/"
        },
        "archives": "http://people.reed.edu/~blancheh/archives.html"
    }
}